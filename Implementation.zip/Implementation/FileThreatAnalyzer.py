# FileThreatAnalyzer.py — Sentinel File Threat Analyzer (v7)
# Fully safe for all office, zip, rar, tar files
from fastapi import APIRouter, UploadFile, File, Request
from fastapi.responses import JSONResponse
from fastapi.templating import Jinja2Templates

import os, tempfile, hashlib, mimetypes, datetime, logging, zipfile, tarfile, json, math, requests
from pathlib import Path
from typing import List

try:
    import yara
except Exception:
    yara = None

try:
    from oletools.olevba3 import VBA_Parser
except Exception:
    VBA_Parser = None

try:
    import rarfile
except Exception:
    rarfile = None

try:
    import pefile
except Exception:
    pefile = None

from groq import Groq

router = APIRouter()
templates = Jinja2Templates(directory="templates")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("FileThreatAnalyzer")

AI = Groq(api_key=os.getenv("GROQ_API_KEY"))
VT_API_KEY = os.getenv("VT_API_KEY")


def hash_file(path: str) -> dict:
    h = {"sha256": hashlib.sha256(), "md5": hashlib.md5(), "sha1": hashlib.sha1()}
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                for algo in h.values():
                    algo.update(chunk)
    except Exception:
        pass
    return {k: v.hexdigest() for k, v in h.items()}


def file_metadata(path: str) -> dict:
    try:
        stat = os.stat(path)
        mime, _ = mimetypes.guess_type(path)
        return {
            "size_bytes": stat.st_size,
            "mime_type": mime or "unknown",
            "created": datetime.datetime.fromtimestamp(stat.st_ctime).isoformat(),
            "modified": datetime.datetime.fromtimestamp(stat.st_mtime).isoformat()
        }
    except Exception:
        return {}


def calculate_entropy(path: str) -> float:
    try:
        with open(path, "rb") as f:
            data = f.read(200_000)
        if not data:
            return 0.0
        freq = [0] * 256
        for b in data:
            freq[b] += 1
        entropy = 0.0
        for c in freq:
            if c:
                p = c / len(data)
                entropy -= p * math.log2(p)
        return round(entropy, 2)
    except Exception:
        return 0.0


def analyze_pe(path: str) -> dict:
    if not pefile:
        return {}
    try:
        pe = pefile.PE(path)
        entropy = max(s.get_entropy() for s in pe.sections)
        return {
            "is_pe": True,
            "imports": len(pe.DIRECTORY_ENTRY_IMPORT),
            "sections": len(pe.sections),
            "max_section_entropy": round(entropy, 2),
            "packed": entropy > 7.2
        }
    except Exception:
        return {}


def vt_lookup(sha256: str) -> dict | None:
    if not VT_API_KEY:
        return None
    try:
        r = requests.get(
            f"https://www.virustotal.com/api/v3/files/{sha256}",
            headers={"x-apikey": VT_API_KEY},
            timeout=10
        )
        if r.status_code != 200:
            return None
        stats = r.json().get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
        return {
            "malicious": stats.get("malicious", 0),
            "suspicious": stats.get("suspicious", 0),
            "harmless": stats.get("harmless", 0)
        }
    except Exception:
        return None


def scan_macros(path: str) -> List[str]:
    macros = []

    if not VBA_Parser:
        return macros

    try:
        v = VBA_Parser(path)
        if v.detect_vba_macros():
            macros += [code[:1500] for (_, _, _, code) in v.extract_macros()]
        v.close()
    except Exception:
        pass

    if path.lower().endswith((".docx", ".pptx", ".xlsx", ".xlsm", ".docm", ".pptm")):
        try:
            with zipfile.ZipFile(path) as z:
                for name in z.namelist():
                    if "vbaProject.bin" in name:
                        try:
                            bin_data = z.read(name)
                            with tempfile.NamedTemporaryFile(delete=False) as tmp:
                                tmp.write(bin_data)
                                tmp_path = tmp.name
                            try:
                                v2 = VBA_Parser(tmp_path)
                                if v2.detect_vba_macros():
                                    macros += [code[:1500] for (_, _, _, code) in v2.extract_macros()]
                                v2.close()
                            except Exception:
                                pass
                            finally:
                                os.unlink(tmp_path)
                        except Exception:
                            continue
        except Exception:
            pass
    return macros


def scan_yara(path: str) -> List[str]:
    if not yara or not os.path.exists("yara_rules.yar"):
        return []
    try:
        rules = yara.compile("yara_rules.yar")
        return [m.rule for m in rules.match(path)]
    except Exception:
        return []


def extract_archive(path: str, out: str) -> List[str]:
    extracted = []
    try:
        if zipfile.is_zipfile(path):
            with zipfile.ZipFile(path) as z:
                for m in z.namelist():
                    if ".." not in m:
                        try:
                            z.extract(m, out)
                            extracted.append(os.path.join(out, m))
                        except Exception:
                            continue
        elif tarfile.is_tarfile(path):
            with tarfile.open(path) as t:
                for m in t.getmembers():
                    if m.isfile() and ".." not in m.name:
                        try:
                            t.extract(m, out)
                            extracted.append(os.path.join(out, m.name))
                        except Exception:
                            continue
        elif rarfile and rarfile.is_rarfile(path):
            with rarfile.RarFile(path) as r:
                for m in r.infolist():
                    if ".." not in m.filename:
                        try:
                            r.extract(m, out)
                            extracted.append(os.path.join(out, m.filename))
                        except Exception:
                            continue
    except Exception:
        pass
    return extracted


def extract_text_sample(path: str, limit=30000) -> str | None:
    try:
        mime, _ = mimetypes.guess_type(path)
        if mime and mime.startswith("text"):
            with open(path, "r", errors="ignore") as f:
                return f.read(limit)
        if path.lower().endswith((".docx", ".pptx", ".xlsx", ".xlsm", ".docm", ".pptm")):
            texts = []
            with zipfile.ZipFile(path) as z:
                for name in z.namelist():
                    if name.endswith(".xml") or name.endswith(".txt"):
                        try:
                            data = z.read(name).decode("utf-8", errors="ignore")
                            texts.append(data[:limit])
                        except Exception:
                            continue
            return "\n".join(texts)[:limit] if texts else None
    except Exception:
        return None
    return None


# ===== SMART ENTROPY DECISION =====
def determine_risk(macros, yara_hits, pe, entropy, vt, mime_type=None):
    # Dangerous if Yara or macros
    if yara_hits:
        return "Dangerous"
    if macros:
        return "Dangerous"
    # Packed PE
    if pe.get("packed"):
        return "Suspicious"
    # VirusTotal
    if vt and vt["malicious"] > 0:
        return "Dangerous"

    # High entropy only counts for executables, not ZIP/Office/etc.
    if entropy > 7.5 and pe.get("is_pe", False):
        return "Suspicious"

    return "Safe"


def ai_explain(findings: dict) -> dict:
    try:
        resp = AI.chat.completions.create(
            model="llama-3.1-8b-instant",
            temperature=0.2,
            max_tokens=600,
            messages=[
                {"role": "system", "content": "Explain the findings. Do NOT rescan or judge."},
                {"role": "user", "content": json.dumps(findings)}
            ]
        )
        return {"explanation": resp.choices[0].message.content}
    except Exception:
        return {"explanation": "AI explanation unavailable."}


@router.get("/file-threat-analyzer")
def page(request: Request):
    return templates.TemplateResponse("file_threat_analyzer.html", {"request": request})


@router.post("/scan-file")
async def scan_file(file: UploadFile = File(...)):
    temp_dir = tempfile.mkdtemp()
    path = os.path.join(temp_dir, file.filename)

    try:
        with open(path, "wb") as f:
            while chunk := await file.read(1024 * 1024):
                f.write(chunk)

        meta = file_metadata(path)
        hashes = hash_file(path)
        entropy = calculate_entropy(path)
        pe_info = analyze_pe(path)
        vt = vt_lookup(hashes["sha256"])
        extracted = extract_archive(path, temp_dir)

        macros, yara_hits, samples = [], [], []
        for t in [path] + extracted:
            try:
                macros += scan_macros(t)
            except Exception:
                pass
            try:
                yara_hits += scan_yara(t)
            except Exception:
                pass
            try:
                text = extract_text_sample(t)
                if text:
                    samples.append(text)
            except Exception:
                pass

        # smart entropy: pass mime_type for info if needed
        mime_type = meta.get("mime_type")
        risk = determine_risk(macros, yara_hits, pe_info, entropy, vt, mime_type)

        findings = {
            "risk_level": risk,
            "entropy": entropy,
            "pe_info": pe_info,
            "yara_matches": yara_hits,
            "macros_detected": bool(macros),
            "virustotal": vt
        }

        explanation = ai_explain(findings)

        return JSONResponse({
            "success": True,
            "file": file.filename,
            "metadata": meta,
            "hashes": hashes,
            "analysis": findings,
            "ai_explanation": explanation
        })

    finally:
        for p in Path(temp_dir).rglob("*"):
            if p.is_file():
                try:
                    p.unlink()
                except Exception:
                    pass
        try:
            os.rmdir(temp_dir)
        except Exception:
            pass
