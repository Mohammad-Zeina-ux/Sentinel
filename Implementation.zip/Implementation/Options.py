from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from fastapi.templating import Jinja2Templates
import json
import os
from threading import Lock
import hashlib
from datetime import datetime

router = APIRouter()
templates = Jinja2Templates(directory="templates")

# -------------------------
# Options persistence
# -------------------------
OPTIONS_FILE = "options.json"
options_lock = Lock()

# Load existing options or initialize defaults
if os.path.exists(OPTIONS_FILE):
    with open(OPTIONS_FILE, "r", encoding="utf-8") as f:
        try:
            options_store = json.load(f)
        except json.JSONDecodeError:
            options_store = {}
else:
    options_store = {}

# Default options
DEFAULT_OPTIONS = {
    "profile": {"username": "default_user", "email": "user@example.com", "password_hash": hashlib.sha256("password".encode()).hexdigest()},
    "account_settings": {"auto_logout_minutes": 15, "active_sessions": []},
    "ai_preferences": {"response_style": "balanced", "security_strictness": "standard", "proactive_warnings": True},
    "privacy_controls": {"save_chats": True, "chat_auto_delete_days": 30, "vault_mask_by_default": True},
    "notification_settings": {"weak_password_alerts": True, "phishing_alerts": True, "data_breach_alerts": True, "summary_frequency": "weekly"},
    "module_toggles": {"password_tester": True, "threat_advisor": True, "file_threat_analyzer": True, "endpoint_scanner": True, "firewall_manager": False, "digital_forensics": False},
    "appearance": {"theme": "dark", "font_size": "medium", "enter_to_send": True, "auto_scroll_chat": True},
    "advanced": {"enable_experimental_features": False, "show_ai_reasoning": False, "export_logs_format": "json", "verbose_scan_output": False},
    "system_info": {"version": "1.0", "ai_model": "LLaMA 3.1", "last_update": "2025-12-16", "system_health": "OK"}
}

# -------------------------
# Helper to save to file
# -------------------------
def save_options():
    with options_lock:
        with open(OPTIONS_FILE, "w", encoding="utf-8") as f:
            json.dump(options_store, f, indent=4)

# -------------------------
# Routes
# -------------------------
@router.get("/options")
async def options_page(request: Request):
    return templates.TemplateResponse("options.html", {"request": request})

@router.get("/get-options")
async def get_options(user: str = "default_user"):
    if user not in options_store:
        options_store[user] = DEFAULT_OPTIONS.copy()
        save_options()
    return JSONResponse(options_store[user])

@router.post("/update-options")
async def update_options(request: Request):
    data = await request.json()
    user = data.get("user", "default_user")
    category = data.get("category")
    new_values = data.get("values", {})

    if user not in options_store:
        options_store[user] = DEFAULT_OPTIONS.copy()

    # Special handling for profile password change
    if category == "profile" and "password" in new_values:
        old_pwd = new_values.get("old_password", "")
        new_pwd = new_values.get("password", "")
        stored_hash = options_store[user]["profile"]["password_hash"]
        if hashlib.sha256(old_pwd.encode()).hexdigest() != stored_hash:
            return JSONResponse({"success": False, "message": "Old password incorrect"}, status_code=400)
        options_store[user]["profile"]["password_hash"] = hashlib.sha256(new_pwd.encode()).hexdigest()
        save_options()
        return JSONResponse({"success": True, "message": "Password updated successfully"})

    # Update category normally
    if category not in options_store[user]:
        return JSONResponse({"success": False, "message": f"Invalid category: {category}"}, status_code=400)

    options_store[user][category].update(new_values)
    save_options()
    return JSONResponse({"success": True, "message": f"{category} updated successfully."})

@router.post("/reset-options")
async def reset_options(request: Request):
    data = await request.json()
    user = data.get("user", "default_user")
    options_store[user] = DEFAULT_OPTIONS.copy()
    save_options()
    return JSONResponse({"success": True, "message": "Options reset to defaults."})
