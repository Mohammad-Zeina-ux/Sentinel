# EndpointScanner.py — Sentinel Endpoint Intelligence Engine
# ARP + ICMP + Historical Correlation
# ENTERPRISE-SAFE | JSON-ONLY | FAILURE-ISOLATED

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from fastapi.templating import Jinja2Templates
from threading import Lock
from datetime import datetime
import subprocess, socket, ipaddress, json, os, asyncio, concurrent.futures
from groq import Groq

# =========================
# Setup
# =========================
router = APIRouter()
templates = Jinja2Templates(directory="templates")
client = Groq(api_key=os.getenv("GROQ_API_KEY"))

STORE_FILE = "endpoint_store.json"
lock = Lock()
ICMP_TIMEOUT = 6
AI_TIMEOUT = 8

# =========================
# Persistent Store
# =========================
def load_store():
    if not os.path.exists(STORE_FILE):
        return {}

    try:
        with open(STORE_FILE, "r") as f:
            raw = json.load(f)

        for user in raw:
            for mac in raw[user]:
                raw[user][mac]["sources"] = set(raw[user][mac].get("sources", []))
        return raw
    except Exception:
        return {}

STORE = load_store()

def save_store():
    with lock:
        out = {}
        for user, devices in STORE.items():
            out[user] = {}
            for mac, dev in devices.items():
                d = dev.copy()
                d["sources"] = list(d["sources"])
                out[user][mac] = d

        with open(STORE_FILE, "w") as f:
            json.dump(out, f, indent=4)

# =========================
# Utilities
# =========================
def valid_ip(ip):
    try:
        addr = ipaddress.ip_address(ip)
        return not (addr.is_loopback or addr.is_multicast or addr.is_unspecified)
    except Exception:
        return False

def is_virtual_subnet(ip):
    return ip.startswith(("192.168.56.", "192.168.99.", "10.0.2."))

# =========================
# ARP
# =========================
def arp_snapshot():
    devices = []
    try:
        r = subprocess.run(["arp", "-a"], capture_output=True, text=True, shell=True)
        for line in r.stdout.splitlines():
            parts = line.split()
            if len(parts) < 2:
                continue

            ip = parts[0]
            mac = parts[1].replace("-", ":").lower()

            if not valid_ip(ip) or is_virtual_subnet(ip):
                continue

            devices.append({
                "ip": ip,
                "mac": mac,
                "vendor": "Unknown Vendor",
                "device_type": "Unknown",
                "source": "arp"
            })
    except Exception:
        pass

    return devices

# =========================
# ICMP
# =========================
def icmp_probe(ip):
    try:
        return subprocess.run(
            ["ping", "-n", "1", "-w", "120", ip],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        ).returncode == 0
    except Exception:
        return False

def icmp_sweep():
    devices = []
    try:
        local_ip = socket.gethostbyname(socket.gethostname())
        subnet = ".".join(local_ip.split(".")[:-1])
        targets = [f"{subnet}.{i}" for i in range(1, 255)]

        with concurrent.futures.ThreadPoolExecutor(max_workers=40) as ex:
            futures = {ex.submit(icmp_probe, ip): ip for ip in targets}
            for f in concurrent.futures.as_completed(futures, timeout=ICMP_TIMEOUT):
                ip = futures[f]
                if f.result() and not is_virtual_subnet(ip):
                    devices.append({
                        "ip": ip,
                        "mac": f"icmp_only_{ip}",
                        "vendor": "Unknown Vendor",
                        "device_type": "Unknown",
                        "source": "icmp"
                    })
    except Exception:
        pass

    return devices

# =========================
# Correlation
# =========================
def correlate(user, observations):
    now = datetime.utcnow().isoformat()
    history = STORE.setdefault(user, {})

    for obs in observations:
        mac = obs["mac"]
        if mac not in history:
            history[mac] = {
                **obs,
                "first_seen": now,
                "last_seen": now,
                "times_seen": 1,
                "sources": {obs["source"]},
                "visibility": "HIGH" if obs["source"] == "arp" else "LOW",
                "behavior": {"new_device": True}
            }
        else:
            d = history[mac]
            d["last_seen"] = now
            d["times_seen"] += 1
            d["sources"].add(obs["source"])
            d["behavior"]["new_device"] = False

    save_store()

# =========================
# Risk
# =========================
def risk_score(dev):
    score = 0
    if dev["device_type"] == "Unknown":
        score += 20
    if dev["vendor"] == "Unknown Vendor":
        score += 15
    if dev["visibility"] == "LOW":
        score += 15
    if dev["behavior"]["new_device"]:
        score += 25
    return score

# =========================
# AI (FAIL-SAFE)
# =========================
async def ai_analyze_safe(dev, score):
    try:
        prompt = f"IP {dev['ip']} | MAC {dev['mac']} | Risk {score}"
        r = await asyncio.wait_for(
            asyncio.to_thread(
                client.chat.completions.create,
                model="llama-3.1-8b-instant",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.2
            ),
            timeout=AI_TIMEOUT
        )
        return r.choices[0].message.content.strip()
    except Exception:
        return "AI analysis skipped due to timeout or error."

# =========================
# Routes
# =========================
@router.get("/endpoint-scanner")
async def page(request: Request):
    return templates.TemplateResponse("endpoint_scanner.html", {"request": request})

@router.post("/endpoint-scanner/scan")
async def scan(request: Request):
    try:
        data = await request.json()
        user = data.get("user", "default_user")
        correlate(user, arp_snapshot() + icmp_sweep())
        return JSONResponse({"success": True})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@router.get("/endpoint-scanner/analysis")
async def analysis(user: str = "default_user"):
    try:
        devices = STORE.get(user, {})
        results = []

        for dev in devices.values():
            score = risk_score(dev)
            ai = await ai_analyze_safe(dev, score)
            results.append({
                "device": {**dev, "sources": list(dev["sources"])},
                "risk_score": score,
                "ai_analysis": ai
            })

        return JSONResponse({
            "success": True,
            "total_devices": len(results),
            "devices": results
        })

    except Exception as e:
        return JSONResponse({
            "success": False,
            "error": "Analysis failed safely",
            "details": str(e)
        }, status_code=500)

@router.post("/endpoint-scanner/clear")
async def clear(request: Request):
    try:
        data = await request.json()
        STORE.pop(data.get("user", "default_user"), None)
        save_store()
        return JSONResponse({"success": True})
    except Exception:
        return JSONResponse({"success": False}, status_code=500)
