# auth.py
from fastapi import APIRouter, Form, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from passlib.context import CryptContext
import sqlite3
from datetime import datetime, timedelta
from urllib.parse import urlencode
import secrets
from email.message import EmailMessage
import smtplib
import os
from dotenv import load_dotenv

# -------------------------
# Load environment variables
# -------------------------
load_dotenv()
EMAIL_ADDRESS = os.getenv("EMAIL_ADDRESS")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")

router = APIRouter()
templates = Jinja2Templates(directory="templates")

# -------------------------
# Password hashing (argon2)
# -------------------------
pwd_context = CryptContext(schemes=["argon2"], deprecated="auto")

# -------------------------
# Database file
# -------------------------
DB_FILE = "sentinel.db"

# -------------------------
# Helper functions
# -------------------------
def get_db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def create_users_table():
    conn = get_db()
    c = conn.cursor()

    # Create table if it doesn't exist (basic columns)
    c.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        email TEXT UNIQUE,
        password_hash TEXT,
        created_at TEXT,
        last_login TEXT
    )
    """)
    conn.commit()

    # Check existing columns
    c.execute("PRAGMA table_info(users)")
    columns = [col[1] for col in c.fetchall()]

    # Add reset_token column if missing
    if "reset_token" not in columns:
        c.execute("ALTER TABLE users ADD COLUMN reset_token TEXT")

    # Add reset_token_expiry column if missing
    if "reset_token_expiry" not in columns:
        c.execute("ALTER TABLE users ADD COLUMN reset_token_expiry TEXT")

    conn.commit()
    conn.close()

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(password: str, hashed: str) -> bool:
    return pwd_context.verify(password, hashed)

def get_user_by_email(email: str):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE email = ?", (email,))
    user = c.fetchone()
    conn.close()
    return user

def get_user_by_username(username: str):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username = ?", (username,))
    user = c.fetchone()
    conn.close()
    return user

# -------------------------
# Signup
# -------------------------
@router.post("/signup")
def signup(username: str = Form(...), email: str = Form(...), password: str = Form(...)):
    create_users_table()

    if get_user_by_email(email) or get_user_by_username(username):
        params = urlencode({"error": "User already exists", "username": username, "email": email})
        return RedirectResponse(f"/signup?{params}", status_code=302)

    hashed_pw = hash_password(password)
    created_at = datetime.utcnow().isoformat()

    conn = get_db()
    c = conn.cursor()
    c.execute(
        "INSERT INTO users (username, email, password_hash, created_at) VALUES (?, ?, ?, ?)",
        (username, email, hashed_pw, created_at)
    )
    conn.commit()
    conn.close()

    response = RedirectResponse("/dashboard", status_code=302)
    response.set_cookie(key="user", value=email)
    return response

# -------------------------
# Login
# -------------------------
@router.post("/login")
def login(identifier: str = Form(...), password: str = Form(...)):
    user = get_user_by_email(identifier) or get_user_by_username(identifier)

    if not user or not verify_password(password, user["password_hash"]):
        params = urlencode({"error": "Invalid credentials", "identifier": identifier})
        return RedirectResponse(f"/login?{params}", status_code=302)

    # Update last login
    conn = get_db()
    c = conn.cursor()
    c.execute(
        "UPDATE users SET last_login = ? WHERE id = ?",
        (datetime.utcnow().isoformat(), user["id"])
    )
    conn.commit()
    conn.close()

    # Redirect to splash/loading page first (shield animation)
    response = RedirectResponse("/loading", status_code=302)
    response.set_cookie(key="user", value=user["email"])
    return response

# -------------------------
# Forgot Password Page
# -------------------------
@router.get("/forgot-password")
def forgot_password_page(request: Request):
    return templates.TemplateResponse(
        "verification.html",
        {"request": request}
    )

# -------------------------
# Forgot Password Request
# -------------------------
@router.post("/forgot-password")
def forgot_password(email: str = Form(...)):
    create_users_table()  # ensure table exists and columns exist
    user = get_user_by_email(email)

    if user:
        token = secrets.token_urlsafe(32)
        expiry = (datetime.utcnow() + timedelta(minutes=15)).isoformat()

        conn = get_db()
        c = conn.cursor()
        c.execute(
            "UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE email = ?",
            (token, expiry, email)
        )
        conn.commit()
        conn.close()

        # Send email via Gmail SMTP
        try:
            msg = EmailMessage()
            msg['Subject'] = 'Sentinel Password Reset'
            msg['From'] = EMAIL_ADDRESS
            msg['To'] = email
            msg.set_content(f"""
Hello {user['username']},

You requested a password reset for Sentinel. Click the link below to reset your password:

http://localhost:8000/reset-password?token={token}

This link will expire in 15 minutes.
If you did not request this, you can ignore this email.
""")
            with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
                smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
                smtp.send_message(msg)

            print(f"[EMAIL SENT] Reset link sent to {email}")
        except Exception as e:
            print(f"[EMAIL ERROR] {e}")

    params = urlencode({"message": "If the email exists, a reset link was sent"})
    return RedirectResponse(f"/forgot-password?{params}", status_code=302)

# -------------------------
# Reset Password
# -------------------------
@router.post("/reset-password")
def reset_password(token: str = Form(...), new_password: str = Form(...)):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE reset_token = ?", (token,))
    user = c.fetchone()

    if not user or datetime.utcnow() > datetime.fromisoformat(user["reset_token_expiry"]):
        params = urlencode({"error": "Invalid or expired token"})
        return RedirectResponse(f"/reset-password?{params}", status_code=302)

    new_hash = hash_password(new_password)

    c.execute("""
        UPDATE users
        SET password_hash = ?, reset_token = NULL, reset_token_expiry = NULL
        WHERE id = ?
    """, (new_hash, user["id"]))

    conn.commit()
    conn.close()

    return RedirectResponse("/login?message=Password reset successful", status_code=302)

# -------------------------
# Logout
# -------------------------
@router.get("/logout")
def logout():
    response = RedirectResponse("/login", status_code=302)
    response.delete_cookie(key="user")
    return response
