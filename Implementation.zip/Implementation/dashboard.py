# dashboard.py 
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse
from groq import Groq
import os
import time
import json
from threading import Lock

router = APIRouter()

# =================================================
# Groq client
# =================================================
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    raise ValueError("❌ GROQ_API_KEY not found")

client = Groq(api_key=GROQ_API_KEY)
MODEL_NAME = "llama-3.1-8b-instant"

print("🛡️ Sentinel AI ready (ChatGPT-style reasoning + stable memory)")

# =================================================
# Memory storage (ROBUST + SELF-HEALING)
# =================================================
MEMORY_FILE = "chat_memory.json"
memory_lock = Lock()

HISTORY_FILE = "chat_history.json"
history_lock = Lock()

if os.path.exists(MEMORY_FILE):
    with open(MEMORY_FILE, "r", encoding="utf-8") as f:
        try:
            MEMORY_STORE = json.load(f)
        except json.JSONDecodeError:
            MEMORY_STORE = {}
else:
    MEMORY_STORE = {}

def save_memory():
    with memory_lock:
        with open(MEMORY_FILE, "w", encoding="utf-8") as f:
            json.dump(MEMORY_STORE, f, indent=2)

def get_user_memory(user: str):
    """
    HARD NORMALIZATION:
    - Ensures memory always exists
    - Ensures summary is ALWAYS a list
    - Repairs corrupted memory automatically
    """
    if user not in MEMORY_STORE or not isinstance(MEMORY_STORE[user], dict):
        MEMORY_STORE[user] = {"summary": []}

    if "summary" not in MEMORY_STORE[user] or not isinstance(MEMORY_STORE[user]["summary"], list):
        MEMORY_STORE[user]["summary"] = []

    return MEMORY_STORE[user]

# =================================================
# Save conversation as single history entry
# =================================================
def save_conversation_to_history(user: str, topic: str, messages: list):
    """Saves the conversation as a single entry with topic as title."""
    with history_lock:
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                try:
                    history_store = json.load(f)
                except json.JSONDecodeError:
                    history_store = {}
        else:
            history_store = {}

        if user not in history_store:
            history_store[user] = []

        entry = {
            "id": int(time.time() * 1000),
            "topic": topic or "General Cybersecurity",
            "messages": messages  # list of dicts {"role": "user"/"sentinel", "text": "..."}
        }

        history_store[user].append(entry)

        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(history_store, f, indent=2)

# =================================================
# Simple conversational handling (lightweight only)
# =================================================
GREETINGS = {"hi", "hello", "hey", "yo"}
THANKS = {"thanks", "thank you", "thx"}
VAGUE_PROBLEMS = {
    "i have an issue",
    "i have a problem",
    "something is wrong",
    "i need help",
    "i need assistance"
}

# =================================================
# System prompt (INTELLIGENCE LIVES HERE)
# =================================================
SYSTEM_PROMPT = """
You are Sentinel, a senior cybersecurity analyst AI.

You communicate like ChatGPT:
- Natural
- Confident
- Direct
- Helpful

Rules:
- Always respond. Never remain silent.
- If a question is vague, ask ONE clear clarifying question.
- If enough information is available, answer immediately.
- Give defensive, safe cybersecurity guidance only.
- Do NOT explain how to perform attacks or bypass security.
- Build on previous answers instead of repeating them.

Memory usage:
- You are given short conversation history.
- Use it to maintain continuity.
- Do not restate things the user already understands unless helpful.

Tone:
Professional, calm, human, decisive.

Scope restriction:
You ONLY answer questions related to cybersecurity, digital safety, privacy, or system security.
If a question is outside this scope, politely decline and redirect back to cybersecurity topics.
For example, say: "I’m focused on cybersecurity topics only. Please ask a question related to digital safety, malware, network security, or system protection."
"""

# =================================================
# Streaming generator
# =================================================
def stream_ai_answer(question: str, user: str):
    q = question.strip()
    ql = q.lower()
    memory = get_user_memory(user)

    # ---- Natural conversation handling ----
    if ql in GREETINGS:
        yield "Hello. How can I help you with cybersecurity today?"
        return

    if ql in THANKS:
        yield "You’re welcome. If you have more questions, I’m here."
        return

    if any(v in ql for v in VAGUE_PROBLEMS):
        yield "I can help with that. Could you briefly describe what’s going on?"
        return

    # ---- Build conversation context (REAL MEMORY) ----
    recent_context = "\n".join(memory["summary"][-6:]) if memory["summary"] else "No prior context."

    user_prompt = f"""
Conversation so far:
{recent_context}

User message:
{q}

Respond naturally and helpfully.
STRICTLY focus on cybersecurity only. If this question is outside cybersecurity, politely decline.
"""

    try:
        stream = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.3,
            max_tokens=900,
            stream=True
        )

        response_text = ""
        conversation_messages = []

        for chunk in stream:
            if chunk.choices and chunk.choices[0].delta and chunk.choices[0].delta.content:
                token = chunk.choices[0].delta.content
                response_text += token
                yield token
                time.sleep(0.015)

        # ---- MEMORY WRITE (SAFE) ----
        if response_text.strip():
            conversation_messages.append({"role": "user", "text": q})
            conversation_messages.append({"role": "sentinel", "text": response_text[:200]})

            memory["summary"].append(f"User: {q}")
            memory["summary"].append(f"Sentinel: {response_text[:300]}")
            save_memory()

            # ---- SAVE AS SINGLE HISTORY ENTRY ----
            save_conversation_to_history(
                user=user,
                topic=memory.get("active_topic", "General Cybersecurity"),
                messages=conversation_messages
            )

    except Exception as e:
        yield f"Sentinel encountered an error: {str(e)}"

# =================================================
# API endpoint (UNCHANGED)
# =================================================
@router.post("/ask-security")
async def ask_security(request: Request):
    data = await request.json()
    question = data.get("question", "")
    user = data.get("user", "default_user")

    if not question.strip():
        return JSONResponse({"answer": "Please ask a cybersecurity question."})

    return StreamingResponse(
        stream_ai_answer(question, user),
        media_type="text/plain"
    )
