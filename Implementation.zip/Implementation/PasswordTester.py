from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from fastapi.templating import Jinja2Templates
from zxcvbn import zxcvbn
from groq import Groq
import os
import json
from threading import Lock
import uuid

router = APIRouter()
templates = Jinja2Templates(directory="templates")

# -------------------------
# Initialize Groq LLaMA 3.1 Instant
# -------------------------
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    raise ValueError("❌ GROQ_API_KEY not found in environment variables")

client = Groq(api_key=GROQ_API_KEY)
MODEL_NAME = "llama-3.1-8b-instant"

print("🚀 Password Tester module ready (Groq + LLaMA 3.1 Instant)")

# -------------------------
# Vault persistence
# -------------------------
VAULT_FILE = "vault.json"
vault_lock = Lock()

if os.path.exists(VAULT_FILE):
    with open(VAULT_FILE, "r", encoding="utf-8") as f:
        try:
            vault_store = json.load(f)
        except json.JSONDecodeError:
            vault_store = {}
else:
    vault_store = {}

def save_vault():
    with vault_lock:
        with open(VAULT_FILE, "w", encoding="utf-8") as f:
            json.dump(vault_store, f, indent=4)

# -------------------------
# LLM helper
# -------------------------
def llm_generate(prompt: str) -> str:
    completion = client.chat.completions.create(
        model=MODEL_NAME,
        messages=[
            {
                "role": "system",
                "content": (
                    "You are Sentinel, a cybersecurity AI assistant. "
                    "You analyze passwords for strength, weaknesses, and improvements. "
                    "Be concise, clear, and practical."
                )
            },
            {"role": "user", "content": prompt}
        ],
        temperature=0.4,
        max_tokens=200,
    )
    return completion.choices[0].message.content.strip()

# -------------------------
# Routes
# -------------------------
@router.get("/password-tester")
async def password_tester_page(request: Request):
    return templates.TemplateResponse("password_tester.html", {"request": request})

@router.post("/evaluate-password")
async def evaluate_password(request: Request):
    data = await request.json()
    password = data.get("password")
    if not password:
        return JSONResponse({"success": False, "message": "No password provided."})

    result = zxcvbn(password)
    score = result["score"]
    crack_time = result["crack_times_display"]["offline_slow_hashing_1e4_per_second"]
    labels = ["Very Weak", "Weak", "Medium", "Strong", "Very Strong"]
    strength_label = labels[score]

    prompt = f"""
Analyze the following password from a cybersecurity perspective.

Password: "{password}"

Provide:
1. A brief strength assessment (1 sentence)
2. Key weaknesses (if any)
3. One specific improvement suggestion

Do not repeat the password.
Do not include disclaimers.
"""
    llm_response = llm_generate(prompt)

    return JSONResponse({
        "success": True,
        "strength": strength_label,
        "crack_time": crack_time,
        "llm_feedback": llm_response
    })

@router.post("/suggest-passwords")
async def suggest_passwords(request: Request):
    data = await request.json()
    memorable = data.get("memorable")
    if not memorable:
        return JSONResponse({"success": False, "message": "No memorable word provided."})

    prompt = f"""
Create 4 strong, memorable passwords that include the phrase "{memorable}".

Rules:
- Include symbols and numbers
- Use capitalization
- Each password on a new line
- Do not add explanations
"""
    llm_response = llm_generate(prompt)
    suggestions = [line.strip() for line in llm_response.split("\n") if line.strip()]
    return JSONResponse({"success": True, "suggestions": suggestions})

# -------------------------
# Vault API routes
# -------------------------
@router.get("/get-vault")
async def get_vault(user: str = "default_user"):
    return JSONResponse(vault_store.get(user, []))

@router.post("/vault/add")
async def add_to_vault(request: Request):
    data = await request.json()
    user = data.get("username", "default_user")
    label = data.get("label", "Generated Password")
    password = data.get("password")

    if not password:
        return JSONResponse({"success": False, "message": "Password missing."})

    if user not in vault_store:
        vault_store[user] = []

    vault_store[user].append({
        "id": str(uuid.uuid4()),
        "label": label,
        "password": password
    })
    save_vault()
    return JSONResponse({"success": True, "message": "Password added to vault."})

@router.post("/delete-vault")
async def delete_vault(request: Request):
    data = await request.json()
    user = data.get("user", "default_user")
    pid = data.get("id")
    if not pid:
        return JSONResponse({"success": False, "message": "ID missing."})

    user_vault = vault_store.get(user, [])
    new_vault = [p for p in user_vault if p.get("id") != pid]

    if len(new_vault) == len(user_vault):
        return JSONResponse({"success": False, "message": "Password not found."}, status_code=404)

    vault_store[user] = new_vault
    save_vault()
    return JSONResponse({"success": True, "message": "Password deleted."})

@router.post("/clear-vault")
async def clear_vault(request: Request):
    data = await request.json()
    user = data.get("user", "default_user")
    vault_store[user] = []
    save_vault()
    return JSONResponse({"success": True, "message": "Vault cleared."})
