print("=== SENTINEL MAIN LOADED ===")

import sys
import asyncio
import os
import json
import uuid

if sys.platform.startswith("win"):
    asyncio.set_event_loop_policy(
        asyncio.WindowsProactorEventLoopPolicy()
    )

# =========================
# Base directory
# =========================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# =========================
# Ensure static folder exists
# =========================
STATIC_DIR = os.path.join(BASE_DIR, "static")
if not os.path.exists(STATIC_DIR):
    os.makedirs(STATIC_DIR)

# =========================
# FastAPI imports
# =========================
from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

# =========================
# Routers
# =========================
from auth import router as auth_router
from dashboard import router as dashboard_router
from history import router as history_router

from PasswordTester import router as password_tester_router
from PrivacyLeak import router as privacy_leak_router
from WebScanner import router as web_scanner_router
from FileThreatAnalyzer import router as file_threat_analyzer_router
from EndpointScanner import router as endpoint_scanner_router
from Options import router as options_router

# =========================
# App init
# =========================
app = FastAPI(title="Sentinel")

# =========================
# Session middleware
# =========================
app.add_middleware(
    SessionMiddleware,
    secret_key="CHANGE_THIS_TO_A_REAL_SECRET"
)

# =========================
# Static files
# =========================
if os.path.isdir(STATIC_DIR):
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# =========================
# Templates
# =========================
templates = Jinja2Templates(
    directory=os.path.join(BASE_DIR, "templates")
)

# =========================
# Routers
# =========================
app.include_router(auth_router)
app.include_router(dashboard_router)
app.include_router(history_router)
app.include_router(password_tester_router)
app.include_router(privacy_leak_router)
app.include_router(web_scanner_router)
app.include_router(file_threat_analyzer_router)
app.include_router(endpoint_scanner_router)
app.include_router(options_router)

# =========================
# Vault storage
# =========================
VAULT_FILE = os.path.join(BASE_DIR, "vault.json")

# =========================
# Routes
# =========================
@app.get("/")
def root(request: Request):
    user = request.cookies.get("user")
    if user:
        return RedirectResponse("/loading")  # redirect to loading animation first
    return RedirectResponse("/login")


@app.get("/login")
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@app.get("/signup")
def signup_page(request: Request):
    return templates.TemplateResponse("signup.html", {"request": request})


@app.get("/loading")
def loading_page(request: Request):
    user = request.cookies.get("user")
    if not user:
        return RedirectResponse("/login")
    return templates.TemplateResponse("loading.html", {"request": request, "user": user})


@app.get("/dashboard")
def dashboard(request: Request):
    user = request.cookies.get("user")
    if not user:
        return RedirectResponse("/login")
    return templates.TemplateResponse("dashboard.html", {"request": request, "user": user})


@app.get("/history")
def history(request: Request):
    user = request.cookies.get("user")
    if not user:
        return RedirectResponse("/login")
    return templates.TemplateResponse("history.html", {"request": request, "user": user})


@app.get("/vault")
def vault(request: Request):
    user = request.cookies.get("user")
    if not user:
        return RedirectResponse("/login")

    passwords = []
    if os.path.exists(VAULT_FILE):
        with open(VAULT_FILE, "r") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError:
                data = {"vault": []}
            passwords = [item for item in data.get("vault", []) if item.get("username") == user]

    return templates.TemplateResponse("vault.html", {"request": request, "passwords": passwords})


@app.post("/vault/add")
async def add_to_vault(request: Request):
    data = await request.json()
    if not all(data.values()):
        return {"success": False, "message": "Missing fields"}

    vault_data = {"vault": []}
    if os.path.exists(VAULT_FILE):
        with open(VAULT_FILE, "r") as f:
            try:
                vault_data = json.load(f)
            except:
                pass

    vault_data["vault"].append({"id": str(uuid.uuid4()), **data})
    with open(VAULT_FILE, "w") as f:
        json.dump(vault_data, f, indent=4)

    return {"success": True}


@app.get("/help")
def help_page(request: Request):
    user = request.cookies.get("user")
    if not user:
        return RedirectResponse("/login")
    return templates.TemplateResponse("help.html", {"request": request})


@app.get("/feedback")
def feedback_page(request: Request):
    user = request.cookies.get("user")
    if not user:
        return RedirectResponse("/login")
    return templates.TemplateResponse("feedback.html", {"request": request})
