# history.py
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
import json
import os
from threading import Lock
import uuid

router = APIRouter()

# ================================
# File to persist history
# ================================
HISTORY_FILE = "history_store.json"
history_lock = Lock()

# Load existing history or initialize
if os.path.exists(HISTORY_FILE):
    with open(HISTORY_FILE, "r", encoding="utf-8") as f:
        try:
            history_store = json.load(f)
        except json.JSONDecodeError:
            history_store = {}
else:
    history_store = {}

# ================================
# Helpers
# ================================
def save_to_file():
    """Thread-safe save to JSON file"""
    with history_lock:
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(history_store, f, indent=4)

# ================================
# Save conversation
# ================================
@router.post("/save-history")
async def save_history(request: Request):
    """
    Save a conversation to history.
    Expects JSON: {username, topic, messages: [{role, text}]}
    """
    data = await request.json()
    username = data.get("username", "default_user")
    topic = data.get("topic")
    messages = data.get("messages", [])

    if not topic or not messages:
        return JSONResponse({"success": False, "message": "Topic or messages missing."})

    if username not in history_store:
        history_store[username] = []

    history_store[username].append({
        "id": str(uuid.uuid4()),  # unique ID for deletion
        "topic": topic,
        "messages": messages
    })

    save_to_file()
    return JSONResponse({"success": True, "message": "Chat added to history!"})

# ================================
# Get all conversations for a user
# ================================
@router.get("/get-history")
async def get_history(username: str = "default_user"):
    user_history = history_store.get(username, [])
    return JSONResponse(user_history)

# ================================
# Delete a conversation
# ================================
@router.post("/delete-history")
async def delete_history(request: Request):
    """
    Delete a conversation by ID.
    Expects JSON: {username, id}
    """
    data = await request.json()
    username = data.get("username", "default_user")
    conv_id = data.get("id")

    if not username or not conv_id:
        return JSONResponse({"success": False, "message": "Missing username or conversation ID."}, status_code=400)

    user_history = history_store.get(username, [])
    new_history = [conv for conv in user_history if conv.get("id") != conv_id]

    if len(new_history) == len(user_history):
        return JSONResponse({"success": False, "message": "Conversation not found."}, status_code=404)

    history_store[username] = new_history
    save_to_file()
    return JSONResponse({"success": True, "message": "Conversation deleted."})

# ================================
# Clear all conversations for a user
# ================================
@router.post("/clear-history")
async def clear_history(request: Request):
    """
    Clear all conversations for a given user.
    Expects JSON: {username}
    """
    data = await request.json()
    username = data.get("username", "default_user")

    if username in history_store:
        history_store[username] = []
        save_to_file()

    return JSONResponse({"success": True, "message": "All conversations cleared."})
