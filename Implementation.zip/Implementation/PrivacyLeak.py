from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from fastapi.templating import Jinja2Templates
from groq import Groq
import os

router = APIRouter()
templates = Jinja2Templates(directory="templates")

# -------------------------
# Initialize Groq LLaMA 3.1 Instant
# -------------------------
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    raise ValueError("❌ GROQ_API_KEY not found in environment variables")

client = Groq(api_key=GROQ_API_KEY)
MODEL_NAME = "llama-3.1-8b-instant"

print("🛡️ Privacy Leak Analyzer module ready (Groq + LLaMA 3.1 Instant)")

# -------------------------
# LLM helper (same pattern as PasswordTester)
# -------------------------
def llm_generate(prompt: str) -> str:
    completion = client.chat.completions.create(
        model=MODEL_NAME,
        messages=[
            {
                "role": "system",
                "content": (
                    "You are Sentinel, an advanced cybersecurity AI. "
                    "You analyze emails for phishing, scams, impersonation, "
                    "and social engineering. You detect subtle manipulation "
                    "techniques humans often miss. Be precise and analytical."
                )
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0.3,
        max_tokens=500,
    )

    return completion.choices[0].message.content.strip()

# -------------------------
# Routes
# -------------------------
@router.get("/privacy-leak-analyzer")
async def privacy_leak_page(request: Request):
    return templates.TemplateResponse("privacy_leak.html", {"request": request})

@router.post("/analyze-email")
async def analyze_email(request: Request):
    data = await request.json()

    sender = data.get("sender")
    recipient = data.get("recipient")
    subject = data.get("subject")
    body = data.get("body")

    if not all([sender, recipient, subject, body]):
        return JSONResponse({
            "success": False,
            "message": "Missing email fields."
        })

    prompt = f"""
Analyze the following email for security and privacy risks.

Email:
From: {sender}
To: {recipient}
Subject: {subject}

Body:
{body}

Tasks:
1. Segment the email logically (headers, subject, body content).
2. Identify phishing, scam, or social engineering techniques.
3. Detect subtle red flags (urgency, authority abuse, impersonation, fear, rewards).
4. Determine if the email is legitimate or malicious.

Return the analysis in this exact format:

Verdict: Safe / Suspicious / Scam
Risk Score: 0-100

Detailed Analysis:
- Sender & Header Analysis:
- Subject Line Analysis:
- Body Content Analysis:
- Psychological / Social Engineering Indicators:
- Subtle Red Flags Humans Miss:
- Final Verdict Explanation:

Do not include disclaimers.
"""

    llm_response = llm_generate(prompt)

    return JSONResponse({
        "success": True,
        "analysis": llm_response
    })
