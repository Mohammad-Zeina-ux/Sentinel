from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from fastapi.templating import Jinja2Templates
from urllib.parse import urlparse
import httpx
import re
import os
import socket

router = APIRouter(prefix="/web-scanner", tags=["Web Scanner"])
templates = Jinja2Templates(directory="templates")

USE_AI = False
groq_client = None

try:
    from groq import Groq
    if os.getenv("GROQ_API_KEY"):
        groq_client = Groq(api_key=os.getenv("GROQ_API_KEY"))
        USE_AI = True
except Exception:
    USE_AI = False

MODEL_NAME = "llama-3.1-8b-instant"

TRUSTED_DOMAINS = {
    "google.com", "youtube.com", "discord.com", "github.com",
    "microsoft.com", "apple.com", "amazon.com", "cloudflare.com",
    "facebook.com", "netflix.com", "spotify.com", "twitter.com",
    "linkedin.com", "reddit.com", "wikipedia.org", "stackoverflow.com",
    "medium.com", "zoom.us", "slack.com", "dropbox.com", "adobe.com"
}

BRAND_KEYWORDS = [
    "google", "discord", "paypal", "apple", "microsoft",
    "facebook", "instagram", "netflix", "amazon", "twitter",
    "linkedin", "reddit", "youtube", "adobe", "dropbox", "slack",
    "zoom", "medium"
]

URGENT_PHRASES = [
    "verify immediately", "account suspended", "unusual activity",
    "action required", "security alert", "confirm your identity",
    "limited time", "password expired", "update payment", "login required"
]

SUSPICIOUS_TLDS = {".xyz", ".top", ".click", ".site", ".space", ".club", ".online", ".info", ".tech"}

PIRACY_KEYWORDS = [
    "gogoanime", "9anime", "animeflix", "kissanime", "watchcartoononline",
    "movies123", "soap2day", "soaap2day", "soapp2day", "putlocker", "fmovies", "gomovies",
    "123movies", "movie4k", "solarmovie", "yify", "yesmovies",
    "animeheaven", "animestream", "animenova", "hdpopcorns", "animeland"
]

@router.get("")
def web_scanner_page(request: Request):
    return templates.TemplateResponse("web_scanner.html", {"request": request})

def normalize_url(url: str):
    if not url.startswith(("http://", "https://")):
        return "https://" + url
    return url

def extract_base_domain(domain: str):
    parts = domain.split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else domain

def domain_resolves(domain: str):
    try:
        return socket.gethostbyname(domain)
    except Exception:
        return None

def is_low_trust_domain(domain: str):
    if any(domain.endswith(tld) for tld in SUSPICIOUS_TLDS):
        return True
    if re.search(r"\d{3,}", domain):
        return True
    return False

async def analyze_website(url: str):
    findings = []
    risk_score = 0
    threat_class = "LOW_RISK"
    final_url = url

    url = normalize_url(url)
    parsed = urlparse(url)
    domain = parsed.netloc.lower()
    base_domain = extract_base_domain(domain)

    if base_domain in TRUSTED_DOMAINS:
        return {
            "original_url": url,
            "final_url": url,
            "risk_score": 0,
            "verdict": "LIKELY_SAFE",
            "confidence": "HIGH",
            "threat_class": "TRUSTED",
            "findings": ["Known trusted domain"],
            "mitre_attack": []
        }

    if is_low_trust_domain(domain):
        findings.append("Low-trust or recently registered domain pattern")
        risk_score += 10

    for brand in BRAND_KEYWORDS:
        if brand in domain and base_domain not in TRUSTED_DOMAINS:
            findings.append(f"Possible brand impersonation ({brand})")
            risk_score += 35
            threat_class = "PHISHING"
            break

    for keyword in PIRACY_KEYWORDS:
        if keyword in domain:
            findings.append("Known piracy or illegal streaming platform")
            findings.append("High malware and exploit delivery risk")
            risk_score += 45
            threat_class = "MALWARE_DISTRIBUTION"
            break

    ip = domain_resolves(domain)
    if not ip or ip.startswith(("10.", "192.168.", "172.")):
        findings.append("Suspicious or evasive hosting behavior")
        risk_score += 20

    credentials_detected = False
    obfuscated_js = False
    urgency_detected = False
    missing_trust_pages = True

    try:
        async with httpx.AsyncClient(timeout=12, follow_redirects=True) as client:
            response = await client.get(url)
            final_url = str(response.url)
            html = response.text.lower()

            if re.search(r'type\s*=\s*["\']password["\']', html):
                credentials_detected = True
                findings.append("Credential input field detected")
                risk_score += 20

            if re.search(r"(eval\(|atob\(|fromcharcode)", html):
                obfuscated_js = True
                if is_low_trust_domain(domain) or any(k in domain for k in PIRACY_KEYWORDS):
                    findings.append("Obfuscated JavaScript detected (high risk context)")
                    risk_score += 15
                else:
                    findings.append("Obfuscated JavaScript detected (low risk context)")

            for phrase in URGENT_PHRASES:
                if phrase in html:
                    urgency_detected = True
                    findings.append("Urgent or coercive language detected")
                    risk_score += 15
                    break

            if any(k in html for k in ["privacy policy", "terms of service", "contact us"]):
                missing_trust_pages = False

            script_count = len(re.findall(r"<script", html))
            if script_count > 25:
                findings.append("Excessive third-party scripts detected (malvertising risk)")
                risk_score += 20

    except Exception:
        findings.append("Passive content inspection failed")
        risk_score += 10

    if credentials_detected and missing_trust_pages:
        findings.append("Credential request without trust or legal context")
        risk_score += 25

    risk_score = min(100, risk_score)

    if risk_score >= 80:
        verdict, confidence = "DANGEROUS", "HIGH"
    elif risk_score >= 55:
        verdict, confidence = "SUSPICIOUS", "HIGH"
    elif risk_score >= 30:
        verdict, confidence = "POTENTIALLY RISKY", "MEDIUM"
    else:
        verdict, confidence = "LIKELY SAFE", "LOW"

    if not findings:
        findings.append("No phishing indicators detected (does NOT imply safety)")

    return {
        "original_url": url,
        "final_url": final_url,
        "risk_score": risk_score,
        "verdict": verdict,
        "confidence": confidence,
        "threat_class": threat_class,
        "findings": findings,
        "mitre_attack": []
    }

@router.post("/scan")
async def scan_website(request: Request):
    try:
        data = await request.json()
        url = data.get("url", "").strip()

        if not url:
            return JSONResponse(status_code=400, content={
                "success": False,
                "message": "No URL provided"
            })

        results = await analyze_website(url)
        ai_explanation = None

        if USE_AI and results["risk_score"] >= 20:
            prompt = f"""
You are Sentinel, a senior SOC analyst.

Explain the security assessment clearly.
Do not add new risks.
Do not change the verdict.

URL: {results['original_url']}
Verdict: {results['verdict']}
Risk Score: {results['risk_score']}

Findings:
{chr(10).join("- " + f for f in results['findings'])}
"""
            response = groq_client.chat.completions.create(
                model=MODEL_NAME,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=350
            )
            ai_explanation = response.choices[0].message.content.strip()

        return JSONResponse(content={
            "success": True,
            **results,
            "ai_explanation": ai_explanation
        })

    except Exception as e:
        return JSONResponse(status_code=500, content={
            "success": False,
            "message": "Internal scan error",
            "error": str(e)
        })
